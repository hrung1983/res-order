<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE> New Document </TITLE>
<META NAME="Generator" CONTENT="EditPlus">
<META NAME="Author" CONTENT="">
<META NAME="Keywords" CONTENT="">
<META NAME="Description" CONTENT="">
<meta charset="windows-874">
</HEAD>
<BODY>
<form action="http://www.deesms.com/api1/tosend9.php" method="post">
 <input type="hidden" name="username" value="aplus"/><br />
 <input type="hidden" name="password1" value="aplusbooth"/><br />
 <input type="hidden" name="password2" value="bfijknou78"/><br />

 <input type="hidden" name="number_phone" value="0611424441"/><br />
 <input type="hidden" name="text_msg" value="���ͺ  �ˡ���ǧ 579"/><br />
 <input type="hidden" name="your_number" value="0890332906"/><br />

 <input type="submit" name="submit" value="Submit me!" />
</form>

</BODY>
</HTML>